import * as lambda from 'aws-cdk-lib/aws-lambda';
import axios from 'axios'; // You may need to install the axios package
import { Construct } from 'constructs';

const dotenv = require('dotenv');

dotenv.config();

const clientId = process.env.CLIENT_ENDPOINT;
const clientSecret = process.env.OPENID_CONNECT_CLIENT_SECRET;
const openid_endpoint = process.env.OPENID_CONNECT_CLIENT_ENDPOINT;


export const createMigrateUserLambda = (scope: Construct, id: string): lambda.Function => { 
  return new lambda.Function(scope, id, {
    runtime: lambda.Runtime.NODEJS_18_X,
    handler: 'migrate-user-handler.migrateUserHandler', // Use the correct module specifier
    code: lambda.Code.fromAsset(__dirname), 
  });
};

export const migrateUserHandler = async (event: any): Promise<any> => {
  console.log('Received event:', JSON.stringify(event));

  if (event.triggerSource === 'UserMigration_Authentication') {
    try {
      // Authenticate against Keycloak using OpenID Connect
      const response = await axios.post(
        `${openid_endpoint}`,
        `grant_type=password&client_id=${ clientId }&client_secret=${ clientSecret }&username=${event.userName}&password=${event.request.password}`,
        { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
      );

      if (response.status !== 200) {
        throw new Error('Authentication against Keycloak failed');
      }
      
      // Set the response attributes
      event.response.finalUserStatus = 'CONFIRMED';
      event.response.messageAction = 'SUPPRESS';
      event.response.userAttributes = {
        email_verified: 'true',
      };

      // Retrieve additional user attributes from Keycloak and populate them in event.response.userAttributes

    } catch (err) {
      console.error(err);
      throw err;
    }
  } else {
    throw new Error(`Bad TriggerSource ${event.triggerSource}`);
  }

  return event;
};



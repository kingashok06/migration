"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrateUserHandler = exports.createMigrateUserLambda = void 0;
const lambda = require("aws-cdk-lib/aws-lambda");
const axios_1 = require("axios"); // You may need to install the axios package
const dotenv = require('dotenv');
dotenv.config();
const clientId = process.env.CLIENT_ENDPOINT;
const clientSecret = process.env.OPENID_CONNECT_CLIENT_SECRET;
const openid_endpoint = process.env.OPENID_CONNECT_CLIENT_ENDPOINT;
const createMigrateUserLambda = (scope, id) => {
    return new lambda.Function(scope, id, {
        runtime: lambda.Runtime.NODEJS_18_X,
        handler: 'lambdas/migrate-user-handler.migrateUserHandler',
        code: lambda.Code.fromAsset(__dirname),
    });
};
exports.createMigrateUserLambda = createMigrateUserLambda;
const migrateUserHandler = async (event) => {
    console.log('Received event:', JSON.stringify(event));
    if (event.triggerSource === 'UserMigration_Authentication') {
        try {
            // Authenticate against Keycloak using OpenID Connect
            const response = await axios_1.default.post(`${openid_endpoint}`, `grant_type=password&client_id=${clientId}&client_secret=${clientSecret}&username=${event.userName}&password=${event.request.password}`, { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
            if (response.status !== 200) {
                throw new Error('Authentication against Keycloak failed');
            }
            // Set the response attributes
            event.response.finalUserStatus = 'CONFIRMED';
            event.response.messageAction = 'SUPPRESS';
            event.response.userAttributes = {
                email_verified: 'true',
            };
            // Retrieve additional user attributes from Keycloak and populate them in event.response.userAttributes
        }
        catch (err) {
            console.error(err);
            throw err;
        }
    }
    else {
        throw new Error(`Bad TriggerSource ${event.triggerSource}`);
    }
    return event;
};
exports.migrateUserHandler = migrateUserHandler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWlncmF0ZS11c2VyLWhhbmRsZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJtaWdyYXRlLXVzZXItaGFuZGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxpREFBaUQ7QUFDakQsaUNBQTBCLENBQUMsNENBQTRDO0FBR3ZFLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUVqQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUM7QUFFaEIsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUM7QUFDN0MsTUFBTSxZQUFZLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsQ0FBQztBQUM5RCxNQUFNLGVBQWUsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixDQUFDO0FBRzVELE1BQU0sdUJBQXVCLEdBQUcsQ0FBQyxLQUFnQixFQUFFLEVBQVUsRUFBbUIsRUFBRTtJQUN2RixPQUFPLElBQUksTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsRUFBRSxFQUFFO1FBQ3BDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDLFdBQVc7UUFDbkMsT0FBTyxFQUFFLGlEQUFpRDtRQUMxRCxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDO0tBQ3ZDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQU5XLFFBQUEsdUJBQXVCLDJCQU1sQztBQUVLLE1BQU0sa0JBQWtCLEdBQUcsS0FBSyxFQUFFLEtBQVUsRUFBZ0IsRUFBRTtJQUNuRSxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUV0RCxJQUFJLEtBQUssQ0FBQyxhQUFhLEtBQUssOEJBQThCLEVBQUU7UUFDMUQsSUFBSTtZQUNGLHFEQUFxRDtZQUNyRCxNQUFNLFFBQVEsR0FBRyxNQUFNLGVBQUssQ0FBQyxJQUFJLENBQy9CLEdBQUcsZUFBZSxFQUFFLEVBQ3BCLGlDQUFrQyxRQUFTLGtCQUFtQixZQUFhLGFBQWEsS0FBSyxDQUFDLFFBQVEsYUFBYSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUMzSSxFQUFFLE9BQU8sRUFBRSxFQUFFLGNBQWMsRUFBRSxtQ0FBbUMsRUFBRSxFQUFFLENBQ3JFLENBQUM7WUFFRixJQUFJLFFBQVEsQ0FBQyxNQUFNLEtBQUssR0FBRyxFQUFFO2dCQUMzQixNQUFNLElBQUksS0FBSyxDQUFDLHdDQUF3QyxDQUFDLENBQUM7YUFDM0Q7WUFFRCw4QkFBOEI7WUFDOUIsS0FBSyxDQUFDLFFBQVEsQ0FBQyxlQUFlLEdBQUcsV0FBVyxDQUFDO1lBQzdDLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxHQUFHLFVBQVUsQ0FBQztZQUMxQyxLQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsR0FBRztnQkFDOUIsY0FBYyxFQUFFLE1BQU07YUFDdkIsQ0FBQztZQUVGLHVHQUF1RztTQUV4RztRQUFDLE9BQU8sR0FBRyxFQUFFO1lBQ1osT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNuQixNQUFNLEdBQUcsQ0FBQztTQUNYO0tBQ0Y7U0FBTTtRQUNMLE1BQU0sSUFBSSxLQUFLLENBQUMscUJBQXFCLEtBQUssQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDO0tBQzdEO0lBRUQsT0FBTyxLQUFLLENBQUM7QUFDZixDQUFDLENBQUM7QUFsQ1csUUFBQSxrQkFBa0Isc0JBa0M3QiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIENvZ25pdG9JZGVudGl0eVNlcnZpY2VQcm92aWRlciBmcm9tICdhd3Mtc2RrL2NsaWVudHMvY29nbml0b2lkZW50aXR5c2VydmljZXByb3ZpZGVyJztcbmltcG9ydCAqIGFzIGxhbWJkYSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtbGFtYmRhJztcbmltcG9ydCBheGlvcyBmcm9tICdheGlvcyc7IC8vIFlvdSBtYXkgbmVlZCB0byBpbnN0YWxsIHRoZSBheGlvcyBwYWNrYWdlXG5pbXBvcnQgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcblxuY29uc3QgZG90ZW52ID0gcmVxdWlyZSgnZG90ZW52Jyk7XG5cbmRvdGVudi5jb25maWcoKTtcblxuY29uc3QgY2xpZW50SWQgPSBwcm9jZXNzLmVudi5DTElFTlRfRU5EUE9JTlQ7XG5jb25zdCBjbGllbnRTZWNyZXQgPSBwcm9jZXNzLmVudi5PUEVOSURfQ09OTkVDVF9DTElFTlRfU0VDUkVUO1xuY29uc3Qgb3BlbmlkX2VuZHBvaW50ID0gcHJvY2Vzcy5lbnYuT1BFTklEX0NPTk5FQ1RfQ0xJRU5UX0VORFBPSU5UO1xuXG5cbmV4cG9ydCBjb25zdCBjcmVhdGVNaWdyYXRlVXNlckxhbWJkYSA9IChzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nKTogbGFtYmRhLkZ1bmN0aW9uID0+IHtcbiAgcmV0dXJuIG5ldyBsYW1iZGEuRnVuY3Rpb24oc2NvcGUsIGlkLCB7XG4gICAgcnVudGltZTogbGFtYmRhLlJ1bnRpbWUuTk9ERUpTXzE4X1gsXG4gICAgaGFuZGxlcjogJ2xhbWJkYXMvbWlncmF0ZS11c2VyLWhhbmRsZXIubWlncmF0ZVVzZXJIYW5kbGVyJyxcbiAgICBjb2RlOiBsYW1iZGEuQ29kZS5mcm9tQXNzZXQoX19kaXJuYW1lKSwgXG4gIH0pO1xufTtcblxuZXhwb3J0IGNvbnN0IG1pZ3JhdGVVc2VySGFuZGxlciA9IGFzeW5jIChldmVudDogYW55KTogUHJvbWlzZTxhbnk+ID0+IHtcbiAgY29uc29sZS5sb2coJ1JlY2VpdmVkIGV2ZW50OicsIEpTT04uc3RyaW5naWZ5KGV2ZW50KSk7XG5cbiAgaWYgKGV2ZW50LnRyaWdnZXJTb3VyY2UgPT09ICdVc2VyTWlncmF0aW9uX0F1dGhlbnRpY2F0aW9uJykge1xuICAgIHRyeSB7XG4gICAgICAvLyBBdXRoZW50aWNhdGUgYWdhaW5zdCBLZXljbG9hayB1c2luZyBPcGVuSUQgQ29ubmVjdFxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBheGlvcy5wb3N0KFxuICAgICAgICBgJHtvcGVuaWRfZW5kcG9pbnR9YCxcbiAgICAgICAgYGdyYW50X3R5cGU9cGFzc3dvcmQmY2xpZW50X2lkPSR7IGNsaWVudElkIH0mY2xpZW50X3NlY3JldD0keyBjbGllbnRTZWNyZXQgfSZ1c2VybmFtZT0ke2V2ZW50LnVzZXJOYW1lfSZwYXNzd29yZD0ke2V2ZW50LnJlcXVlc3QucGFzc3dvcmR9YCxcbiAgICAgICAgeyBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJyB9IH1cbiAgICAgICk7XG5cbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgIT09IDIwMCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0F1dGhlbnRpY2F0aW9uIGFnYWluc3QgS2V5Y2xvYWsgZmFpbGVkJyk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIFNldCB0aGUgcmVzcG9uc2UgYXR0cmlidXRlc1xuICAgICAgZXZlbnQucmVzcG9uc2UuZmluYWxVc2VyU3RhdHVzID0gJ0NPTkZJUk1FRCc7XG4gICAgICBldmVudC5yZXNwb25zZS5tZXNzYWdlQWN0aW9uID0gJ1NVUFBSRVNTJztcbiAgICAgIGV2ZW50LnJlc3BvbnNlLnVzZXJBdHRyaWJ1dGVzID0ge1xuICAgICAgICBlbWFpbF92ZXJpZmllZDogJ3RydWUnLFxuICAgICAgfTtcblxuICAgICAgLy8gUmV0cmlldmUgYWRkaXRpb25hbCB1c2VyIGF0dHJpYnV0ZXMgZnJvbSBLZXljbG9hayBhbmQgcG9wdWxhdGUgdGhlbSBpbiBldmVudC5yZXNwb25zZS51c2VyQXR0cmlidXRlc1xuXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHRocm93IG5ldyBFcnJvcihgQmFkIFRyaWdnZXJTb3VyY2UgJHtldmVudC50cmlnZ2VyU291cmNlfWApO1xuICB9XG5cbiAgcmV0dXJuIGV2ZW50O1xufTtcblxuXG4iXX0=
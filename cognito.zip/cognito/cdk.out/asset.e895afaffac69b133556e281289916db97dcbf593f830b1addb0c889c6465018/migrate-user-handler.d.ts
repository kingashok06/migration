import { CognitoUserPoolTriggerEvent } from 'aws-lambda';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
export declare const createMigrateUserLambda: (scope: Construct, id: string) => lambda.Function;
export declare const migrateUserHandler: (event: CognitoUserPoolTriggerEvent) => Promise<CognitoUserPoolTriggerEvent>;

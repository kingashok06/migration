"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrateUserHandler = exports.createMigrateUserLambda = void 0;
const CognitoIdentityServiceProvider = require("aws-sdk/clients/cognitoidentityserviceprovider");
const lambda = require("aws-cdk-lib/aws-lambda");
const axios_1 = require("axios"); // You may need to install the axios package
const cognitoIdentityProvider = new CognitoIdentityServiceProvider();
const createMigrateUserLambda = (scope, id) => {
    return new lambda.Function(scope, id, {
        runtime: lambda.Runtime.NODEJS_18_X,
        handler: 'migrate-user-lambda.migrateUserHandler',
        code: lambda.Code.fromAsset(__dirname),
    });
};
exports.createMigrateUserLambda = createMigrateUserLambda;
const migrateUserHandler = async (event) => {
    console.log('Received event:', JSON.stringify(event));
    if (event.triggerSource === 'UserMigration_Authentication') {
        try {
            // Authenticate against Keycloak using OpenID Connect
            const response = await axios_1.default.post('https://keycloak.novacloud.app/auth/realms/rekap-dev/protocol/openid-connect/token', `grant_type=password&client_id=cognito&client_secret=c0f105ad-f5ac-4ee3-8715-8e61e04f5be0&username=${event.userName}&password=${event.request.password}`, { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
            if (response.status !== 200) {
                throw new Error('Authentication against Keycloak failed');
            }
            // Set the response attributes
            event.response.finalUserStatus = 'CONFIRMED';
            event.response.messageAction = 'SUPPRESS';
            event.response.userAttributes = {
                email_verified: 'true',
            };
            // Retrieve additional user attributes from Keycloak and populate them in event.response.userAttributes
        }
        catch (err) {
            console.error(err);
            throw err;
        }
    }
    else {
        throw new Error(`Bad TriggerSource ${event.triggerSource}`);
    }
    return event;
};
exports.migrateUserHandler = migrateUserHandler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWlncmF0ZS11c2VyLWhhbmRsZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJtaWdyYXRlLXVzZXItaGFuZGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxpR0FBaUc7QUFFakcsaURBQWlEO0FBQ2pELGlDQUEwQixDQUFDLDRDQUE0QztBQUd2RSxNQUFNLHVCQUF1QixHQUFHLElBQUksOEJBQThCLEVBQUUsQ0FBQztBQUU5RCxNQUFNLHVCQUF1QixHQUFHLENBQUMsS0FBZ0IsRUFBRSxFQUFVLEVBQW1CLEVBQUU7SUFDdkYsT0FBTyxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtRQUNwQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXO1FBQ25DLE9BQU8sRUFBRSx3Q0FBd0M7UUFDakQsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQztLQUN2QyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFOVyxRQUFBLHVCQUF1QiwyQkFNbEM7QUFFSyxNQUFNLGtCQUFrQixHQUFHLEtBQUssRUFBRSxLQUFrQyxFQUF3QyxFQUFFO0lBQ25ILE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0lBRXRELElBQUksS0FBSyxDQUFDLGFBQWEsS0FBSyw4QkFBOEIsRUFBRTtRQUMxRCxJQUFJO1lBQ0YscURBQXFEO1lBQ3JELE1BQU0sUUFBUSxHQUFHLE1BQU0sZUFBSyxDQUFDLElBQUksQ0FDL0Isb0ZBQW9GLEVBQ3BGLHFHQUFxRyxLQUFLLENBQUMsUUFBUSxhQUFhLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLEVBQ3hKLEVBQUUsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLG1DQUFtQyxFQUFFLEVBQUUsQ0FDckUsQ0FBQztZQUVGLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxHQUFHLEVBQUU7Z0JBQzNCLE1BQU0sSUFBSSxLQUFLLENBQUMsd0NBQXdDLENBQUMsQ0FBQzthQUMzRDtZQUVELDhCQUE4QjtZQUM5QixLQUFLLENBQUMsUUFBUSxDQUFDLGVBQWUsR0FBRyxXQUFXLENBQUM7WUFDN0MsS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLEdBQUcsVUFBVSxDQUFDO1lBQzFDLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxHQUFHO2dCQUM5QixjQUFjLEVBQUUsTUFBTTthQUN2QixDQUFDO1lBRUYsdUdBQXVHO1NBRXhHO1FBQUMsT0FBTyxHQUFHLEVBQUU7WUFDWixPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ25CLE1BQU0sR0FBRyxDQUFDO1NBQ1g7S0FDRjtTQUFNO1FBQ0wsTUFBTSxJQUFJLEtBQUssQ0FBQyxxQkFBcUIsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUM7S0FDN0Q7SUFFRCxPQUFPLEtBQUssQ0FBQztBQUNmLENBQUMsQ0FBQztBQWxDVyxRQUFBLGtCQUFrQixzQkFrQzdCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgQ29nbml0b0lkZW50aXR5U2VydmljZVByb3ZpZGVyIGZyb20gJ2F3cy1zZGsvY2xpZW50cy9jb2duaXRvaWRlbnRpdHlzZXJ2aWNlcHJvdmlkZXInO1xuaW1wb3J0IHsgQ29nbml0b1VzZXJQb29sVHJpZ2dlckV2ZW50IH0gZnJvbSAnYXdzLWxhbWJkYSc7XG5pbXBvcnQgKiBhcyBsYW1iZGEgZnJvbSAnYXdzLWNkay1saWIvYXdzLWxhbWJkYSc7XG5pbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnOyAvLyBZb3UgbWF5IG5lZWQgdG8gaW5zdGFsbCB0aGUgYXhpb3MgcGFja2FnZVxuaW1wb3J0IHsgQ29uc3RydWN0IH0gZnJvbSAnY29uc3RydWN0cyc7XG5cbmNvbnN0IGNvZ25pdG9JZGVudGl0eVByb3ZpZGVyID0gbmV3IENvZ25pdG9JZGVudGl0eVNlcnZpY2VQcm92aWRlcigpO1xuXG5leHBvcnQgY29uc3QgY3JlYXRlTWlncmF0ZVVzZXJMYW1iZGEgPSAoc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZyk6IGxhbWJkYS5GdW5jdGlvbiA9PiB7XG4gIHJldHVybiBuZXcgbGFtYmRhLkZ1bmN0aW9uKHNjb3BlLCBpZCwge1xuICAgIHJ1bnRpbWU6IGxhbWJkYS5SdW50aW1lLk5PREVKU18xOF9YLFxuICAgIGhhbmRsZXI6ICdtaWdyYXRlLXVzZXItbGFtYmRhLm1pZ3JhdGVVc2VySGFuZGxlcicsXG4gICAgY29kZTogbGFtYmRhLkNvZGUuZnJvbUFzc2V0KF9fZGlybmFtZSksIFxuICB9KTtcbn07XG5cbmV4cG9ydCBjb25zdCBtaWdyYXRlVXNlckhhbmRsZXIgPSBhc3luYyAoZXZlbnQ6IENvZ25pdG9Vc2VyUG9vbFRyaWdnZXJFdmVudCk6IFByb21pc2U8Q29nbml0b1VzZXJQb29sVHJpZ2dlckV2ZW50PiA9PiB7XG4gIGNvbnNvbGUubG9nKCdSZWNlaXZlZCBldmVudDonLCBKU09OLnN0cmluZ2lmeShldmVudCkpO1xuXG4gIGlmIChldmVudC50cmlnZ2VyU291cmNlID09PSAnVXNlck1pZ3JhdGlvbl9BdXRoZW50aWNhdGlvbicpIHtcbiAgICB0cnkge1xuICAgICAgLy8gQXV0aGVudGljYXRlIGFnYWluc3QgS2V5Y2xvYWsgdXNpbmcgT3BlbklEIENvbm5lY3RcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXhpb3MucG9zdChcbiAgICAgICAgJ2h0dHBzOi8va2V5Y2xvYWsubm92YWNsb3VkLmFwcC9hdXRoL3JlYWxtcy9yZWthcC1kZXYvcHJvdG9jb2wvb3BlbmlkLWNvbm5lY3QvdG9rZW4nLFxuICAgICAgICBgZ3JhbnRfdHlwZT1wYXNzd29yZCZjbGllbnRfaWQ9Y29nbml0byZjbGllbnRfc2VjcmV0PWMwZjEwNWFkLWY1YWMtNGVlMy04NzE1LThlNjFlMDRmNWJlMCZ1c2VybmFtZT0ke2V2ZW50LnVzZXJOYW1lfSZwYXNzd29yZD0ke2V2ZW50LnJlcXVlc3QucGFzc3dvcmR9YCxcbiAgICAgICAgeyBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJyB9IH1cbiAgICAgICk7XG5cbiAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgIT09IDIwMCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0F1dGhlbnRpY2F0aW9uIGFnYWluc3QgS2V5Y2xvYWsgZmFpbGVkJyk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIFNldCB0aGUgcmVzcG9uc2UgYXR0cmlidXRlc1xuICAgICAgZXZlbnQucmVzcG9uc2UuZmluYWxVc2VyU3RhdHVzID0gJ0NPTkZJUk1FRCc7XG4gICAgICBldmVudC5yZXNwb25zZS5tZXNzYWdlQWN0aW9uID0gJ1NVUFBSRVNTJztcbiAgICAgIGV2ZW50LnJlc3BvbnNlLnVzZXJBdHRyaWJ1dGVzID0ge1xuICAgICAgICBlbWFpbF92ZXJpZmllZDogJ3RydWUnLFxuICAgICAgfTtcblxuICAgICAgLy8gUmV0cmlldmUgYWRkaXRpb25hbCB1c2VyIGF0dHJpYnV0ZXMgZnJvbSBLZXljbG9hayBhbmQgcG9wdWxhdGUgdGhlbSBpbiBldmVudC5yZXNwb25zZS51c2VyQXR0cmlidXRlc1xuXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHRocm93IG5ldyBFcnJvcihgQmFkIFRyaWdnZXJTb3VyY2UgJHtldmVudC50cmlnZ2VyU291cmNlfWApO1xuICB9XG5cbiAgcmV0dXJuIGV2ZW50O1xufTtcblxuXG4iXX0=
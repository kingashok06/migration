"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CognitoStack = void 0;
const aws = require("aws-sdk");
const migrate_user_handler_1 = require("./migrate-user-handler");
const cdk = require("aws-cdk-lib");
const cognito = require("aws-cdk-lib/aws-cognito");
const ses = require("aws-cdk-lib/aws-ses");
const iam = require("aws-cdk-lib/aws-iam");
class CognitoStack extends cdk.Stack {
    constructor(scope, id, props) {
        super(scope, id, props);
        const sesClient = new aws.SES();
        // Check if the email identity already exists
        sesClient.getIdentityVerificationAttributes({
            Identities: ['yugank@brainerhub.com'],
        }, (err, data) => {
            if (err) {
                // An error occurred, handle it as needed
                console.error('Error checking email identity:', err);
                return;
            }
            if (data.VerificationAttributes && data.VerificationAttributes['yugank@brainerhub.com']) {
                // Email identity exists, no need to create it
                console.log('Email identity already exists:', data.VerificationAttributes['yugank@brainerhub.com']);
                return;
            }
            // Create an Amazon SES Identity for your email address
            const emailIdentity = new ses.CfnEmailIdentity(this, 'EmailIdentity', {
                emailIdentity: 'yugank@brainerhub.com',
            });
            // Add a policy statement to allow Cognito to send emails through SES
            new iam.PolicyStatement({
                actions: ['ses:SendEmail', 'ses:SendRawEmail'],
                effect: iam.Effect.ALLOW,
                principals: [new iam.ServicePrincipal('cognito-idp.amazonaws.com')],
                resources: [emailIdentity.ref], // The ARN of the SES identity
            });
        });
        // Create a Cognito User Pool
        const userPoolProps = {
            userPoolName: 'UserPool',
            selfSignUpEnabled: false,
            signInAliases: { email: true },
            autoVerify: { email: true },
            passwordPolicy: {
                minLength: 8,
                requireLowercase: true,
                // requireUppercase: true,
                // requireDigits: true,
                // requireSymbols: true,
            },
        };
        const userPool = new cognito.UserPool(this, 'UserPool', userPoolProps);
        // const userPool = new cognito.UserPool(this, 'UserPool', userPoolProps);
        // Inside the CognitoStack class
        const migrateUserLambda = (0, migrate_user_handler_1.createMigrateUserLambda)(this, 'MigrateUserLambda');
        // Define the User Pool trigger
        userPool.addTrigger(cognito.UserPoolOperation.PRE_AUTHENTICATION, migrateUserLambda);
        // Create an App Client for the User Pool
        const appClient = userPool.addClient('AppClient', {
            authFlows: { adminUserPassword: true },
        });
        // Output the Cognito User Pool ID and App Client ID
        new cdk.CfnOutput(this, 'UserPoolId', {
            value: userPool.userPoolId,
        });
        new cdk.CfnOutput(this, 'AppClientId', {
            value: appClient.userPoolClientId,
        });
    }
}
exports.CognitoStack = CognitoStack;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29nbml0by1zdGFjay5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNvZ25pdG8tc3RhY2sudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsK0JBQStCO0FBQy9CLGlFQUFpRTtBQUNqRSxtQ0FBbUM7QUFDbkMsbURBQW1EO0FBQ25ELDJDQUEyQztBQUMzQywyQ0FBMkM7QUFHM0MsTUFBYSxZQUFhLFNBQVEsR0FBRyxDQUFDLEtBQUs7SUFDekMsWUFBWSxLQUFnQixFQUFFLEVBQVUsRUFBRSxLQUFzQjtRQUM5RCxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN4QixNQUFNLFNBQVMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUVoQyw2Q0FBNkM7UUFDN0MsU0FBUyxDQUFDLGlDQUFpQyxDQUFDO1lBQzFDLFVBQVUsRUFBRSxDQUFDLHVCQUF1QixDQUFDO1NBQ3RDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDZixJQUFJLEdBQUcsRUFBRTtnQkFDUCx5Q0FBeUM7Z0JBQ3pDLE9BQU8sQ0FBQyxLQUFLLENBQUMsZ0NBQWdDLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ3JELE9BQU87YUFDUjtZQUVELElBQUksSUFBSSxDQUFDLHNCQUFzQixJQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyx1QkFBdUIsQ0FBQyxFQUFFO2dCQUN2Riw4Q0FBOEM7Z0JBQzlDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLEVBQUUsSUFBSSxDQUFDLHNCQUFzQixDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQztnQkFDcEcsT0FBTzthQUNSO1lBRUQsdURBQXVEO1lBQ3ZELE1BQU0sYUFBYSxHQUFHLElBQUksR0FBRyxDQUFDLGdCQUFnQixDQUFDLElBQUksRUFBRSxlQUFlLEVBQUU7Z0JBQ3BFLGFBQWEsRUFBRSx1QkFBdUI7YUFDdkMsQ0FBQyxDQUFDO1lBRUgscUVBQXFFO1lBQ3JFLElBQUksR0FBRyxDQUFDLGVBQWUsQ0FBQztnQkFDdEIsT0FBTyxFQUFFLENBQUMsZUFBZSxFQUFFLGtCQUFrQixDQUFDO2dCQUM5QyxNQUFNLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLO2dCQUN4QixVQUFVLEVBQUUsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO2dCQUNuRSxTQUFTLEVBQUUsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEVBQUUsOEJBQThCO2FBQy9ELENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsNkJBQTZCO1FBQzdCLE1BQU0sYUFBYSxHQUEwQjtZQUMzQyxZQUFZLEVBQUUsVUFBVTtZQUN4QixpQkFBaUIsRUFBRSxLQUFLO1lBQ3hCLGFBQWEsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDOUIsVUFBVSxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRTtZQUMzQixjQUFjLEVBQUU7Z0JBQ2QsU0FBUyxFQUFFLENBQUM7Z0JBQ1osZ0JBQWdCLEVBQUUsSUFBSTtnQkFDdEIsMEJBQTBCO2dCQUMxQix1QkFBdUI7Z0JBQ3ZCLHdCQUF3QjthQUN6QjtTQUNGLENBQUM7UUFHRixNQUFNLFFBQVEsR0FBRyxJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLFVBQVUsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUN2RSwwRUFBMEU7UUFDMUUsZ0NBQWdDO1FBQ2hDLE1BQU0saUJBQWlCLEdBQUcsSUFBQSw4Q0FBdUIsRUFBQyxJQUFJLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztRQUc3RSwrQkFBK0I7UUFFL0IsUUFBUSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsa0JBQWtCLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztRQUdyRix5Q0FBeUM7UUFDekMsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUU7WUFDaEQsU0FBUyxFQUFFLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxFQUFFO1NBQ3ZDLENBQUMsQ0FBQztRQUVILG9EQUFvRDtRQUNwRCxJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLFlBQVksRUFBRTtZQUNwQyxLQUFLLEVBQUUsUUFBUSxDQUFDLFVBQVU7U0FDM0IsQ0FBQyxDQUFDO1FBRUgsSUFBSSxHQUFHLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxhQUFhLEVBQUU7WUFDckMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxnQkFBZ0I7U0FDbEMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBNUVELG9DQTRFQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIGF3cyBmcm9tICdhd3Mtc2RrJztcbmltcG9ydCB7IGNyZWF0ZU1pZ3JhdGVVc2VyTGFtYmRhIH0gZnJvbSAnLi9taWdyYXRlLXVzZXItaGFuZGxlcic7XG5pbXBvcnQgKiBhcyBjZGsgZnJvbSAnYXdzLWNkay1saWInO1xuaW1wb3J0ICogYXMgY29nbml0byBmcm9tICdhd3MtY2RrLWxpYi9hd3MtY29nbml0byc7XG5pbXBvcnQgKiBhcyBzZXMgZnJvbSAnYXdzLWNkay1saWIvYXdzLXNlcyc7XG5pbXBvcnQgKiBhcyBpYW0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWlhbSc7XG5pbXBvcnQgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcblxuZXhwb3J0IGNsYXNzIENvZ25pdG9TdGFjayBleHRlbmRzIGNkay5TdGFjayB7XG4gIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzPzogY2RrLlN0YWNrUHJvcHMpIHtcbiAgICBzdXBlcihzY29wZSwgaWQsIHByb3BzKTtcbiAgICBjb25zdCBzZXNDbGllbnQgPSBuZXcgYXdzLlNFUygpO1xuXG4gICAgLy8gQ2hlY2sgaWYgdGhlIGVtYWlsIGlkZW50aXR5IGFscmVhZHkgZXhpc3RzXG4gICAgc2VzQ2xpZW50LmdldElkZW50aXR5VmVyaWZpY2F0aW9uQXR0cmlidXRlcyh7XG4gICAgICBJZGVudGl0aWVzOiBbJ3l1Z2Fua0BicmFpbmVyaHViLmNvbSddLFxuICAgIH0sIChlcnIsIGRhdGEpID0+IHtcbiAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgLy8gQW4gZXJyb3Igb2NjdXJyZWQsIGhhbmRsZSBpdCBhcyBuZWVkZWRcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgY2hlY2tpbmcgZW1haWwgaWRlbnRpdHk6JywgZXJyKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBpZiAoZGF0YS5WZXJpZmljYXRpb25BdHRyaWJ1dGVzICYmIGRhdGEuVmVyaWZpY2F0aW9uQXR0cmlidXRlc1sneXVnYW5rQGJyYWluZXJodWIuY29tJ10pIHtcbiAgICAgICAgLy8gRW1haWwgaWRlbnRpdHkgZXhpc3RzLCBubyBuZWVkIHRvIGNyZWF0ZSBpdFxuICAgICAgICBjb25zb2xlLmxvZygnRW1haWwgaWRlbnRpdHkgYWxyZWFkeSBleGlzdHM6JywgZGF0YS5WZXJpZmljYXRpb25BdHRyaWJ1dGVzWyd5dWdhbmtAYnJhaW5lcmh1Yi5jb20nXSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gQ3JlYXRlIGFuIEFtYXpvbiBTRVMgSWRlbnRpdHkgZm9yIHlvdXIgZW1haWwgYWRkcmVzc1xuICAgICAgY29uc3QgZW1haWxJZGVudGl0eSA9IG5ldyBzZXMuQ2ZuRW1haWxJZGVudGl0eSh0aGlzLCAnRW1haWxJZGVudGl0eScsIHtcbiAgICAgICAgZW1haWxJZGVudGl0eTogJ3l1Z2Fua0BicmFpbmVyaHViLmNvbScsIFxuICAgICAgfSk7XG5cbiAgICAgIC8vIEFkZCBhIHBvbGljeSBzdGF0ZW1lbnQgdG8gYWxsb3cgQ29nbml0byB0byBzZW5kIGVtYWlscyB0aHJvdWdoIFNFU1xuICAgICAgbmV3IGlhbS5Qb2xpY3lTdGF0ZW1lbnQoe1xuICAgICAgICBhY3Rpb25zOiBbJ3NlczpTZW5kRW1haWwnLCAnc2VzOlNlbmRSYXdFbWFpbCddLFxuICAgICAgICBlZmZlY3Q6IGlhbS5FZmZlY3QuQUxMT1csXG4gICAgICAgIHByaW5jaXBhbHM6IFtuZXcgaWFtLlNlcnZpY2VQcmluY2lwYWwoJ2NvZ25pdG8taWRwLmFtYXpvbmF3cy5jb20nKV0sXG4gICAgICAgIHJlc291cmNlczogW2VtYWlsSWRlbnRpdHkucmVmXSwgLy8gVGhlIEFSTiBvZiB0aGUgU0VTIGlkZW50aXR5XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIC8vIENyZWF0ZSBhIENvZ25pdG8gVXNlciBQb29sXG4gICAgY29uc3QgdXNlclBvb2xQcm9wczogY29nbml0by5Vc2VyUG9vbFByb3BzID0ge1xuICAgICAgdXNlclBvb2xOYW1lOiAnVXNlclBvb2wnLFxuICAgICAgc2VsZlNpZ25VcEVuYWJsZWQ6IGZhbHNlLCAvLyBBbGxvdyB1c2VycyB0byBzaWduIHVwIHRoZW1zZWx2ZXNcbiAgICAgIHNpZ25JbkFsaWFzZXM6IHsgZW1haWw6IHRydWUgfSwgLy8gRW5hYmxlIHNpZ24taW4gd2l0aCBlbWFpbFxuICAgICAgYXV0b1ZlcmlmeTogeyBlbWFpbDogdHJ1ZSB9LCAvLyBBdXRvbWF0aWNhbGx5IHZlcmlmeSBlbWFpbCBhZGRyZXNzZXNcbiAgICAgIHBhc3N3b3JkUG9saWN5OiB7XG4gICAgICAgIG1pbkxlbmd0aDogOCwgLy8gU2V0IHBhc3N3b3JkIHBvbGljeSBcbiAgICAgICAgcmVxdWlyZUxvd2VyY2FzZTogdHJ1ZSxcbiAgICAgICAgLy8gcmVxdWlyZVVwcGVyY2FzZTogdHJ1ZSxcbiAgICAgICAgLy8gcmVxdWlyZURpZ2l0czogdHJ1ZSxcbiAgICAgICAgLy8gcmVxdWlyZVN5bWJvbHM6IHRydWUsXG4gICAgICB9LFxuICAgIH07XG4gICAgXG4gICAgXG4gICAgY29uc3QgdXNlclBvb2wgPSBuZXcgY29nbml0by5Vc2VyUG9vbCh0aGlzLCAnVXNlclBvb2wnLCB1c2VyUG9vbFByb3BzKTtcbiAgICAvLyBjb25zdCB1c2VyUG9vbCA9IG5ldyBjb2duaXRvLlVzZXJQb29sKHRoaXMsICdVc2VyUG9vbCcsIHVzZXJQb29sUHJvcHMpO1xuICAgIC8vIEluc2lkZSB0aGUgQ29nbml0b1N0YWNrIGNsYXNzXG4gICAgY29uc3QgbWlncmF0ZVVzZXJMYW1iZGEgPSBjcmVhdGVNaWdyYXRlVXNlckxhbWJkYSh0aGlzLCAnTWlncmF0ZVVzZXJMYW1iZGEnKTtcblxuXG4gICAgLy8gRGVmaW5lIHRoZSBVc2VyIFBvb2wgdHJpZ2dlclxuICAgIFxuICAgIHVzZXJQb29sLmFkZFRyaWdnZXIoY29nbml0by5Vc2VyUG9vbE9wZXJhdGlvbi5QUkVfQVVUSEVOVElDQVRJT04sIG1pZ3JhdGVVc2VyTGFtYmRhKTtcblxuXG4gICAgLy8gQ3JlYXRlIGFuIEFwcCBDbGllbnQgZm9yIHRoZSBVc2VyIFBvb2xcbiAgICBjb25zdCBhcHBDbGllbnQgPSB1c2VyUG9vbC5hZGRDbGllbnQoJ0FwcENsaWVudCcsIHtcbiAgICAgIGF1dGhGbG93czogeyBhZG1pblVzZXJQYXNzd29yZDogdHJ1ZSB9LFxuICAgIH0pO1xuXG4gICAgLy8gT3V0cHV0IHRoZSBDb2duaXRvIFVzZXIgUG9vbCBJRCBhbmQgQXBwIENsaWVudCBJRFxuICAgIG5ldyBjZGsuQ2ZuT3V0cHV0KHRoaXMsICdVc2VyUG9vbElkJywge1xuICAgICAgdmFsdWU6IHVzZXJQb29sLnVzZXJQb29sSWQsXG4gICAgfSk7XG5cbiAgICBuZXcgY2RrLkNmbk91dHB1dCh0aGlzLCAnQXBwQ2xpZW50SWQnLCB7XG4gICAgICB2YWx1ZTogYXBwQ2xpZW50LnVzZXJQb29sQ2xpZW50SWQsXG4gICAgfSk7XG4gIH1cbn1cblxuIl19
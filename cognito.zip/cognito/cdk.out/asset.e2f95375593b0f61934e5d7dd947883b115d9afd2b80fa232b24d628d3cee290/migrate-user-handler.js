"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.migrateUserHandler = exports.createMigrateUserLambda = void 0;
const CognitoIdentityServiceProvider = require("aws-sdk/clients/cognitoidentityserviceprovider");
const lambda = require("aws-cdk-lib/aws-lambda");
const axios_1 = require("axios"); // You may need to install the axios package
const cognitoIdentityProvider = new CognitoIdentityServiceProvider();
const createMigrateUserLambda = (scope, id) => {
    return new lambda.Function(scope, id, {
        runtime: lambda.Runtime.NODEJS_18_X,
        handler: 'migrate-user-lambda.migrateUserHandler',
        code: lambda.Code.fromAsset(__dirname),
    });
};
exports.createMigrateUserLambda = createMigrateUserLambda;
const migrateUserHandler = async (event) => {
    console.log('Received event:', JSON.stringify(event));
    if (event.triggerSource === 'UserMigration_Authentication') {
        try {
            // Authenticate against Keycloak using OpenID Connect
            const response = await axios_1.default.post('https://keycloak.novacloMigrateUserLambdaud.app/auth/realms/rekap-dev/protocol/openid-connect/token', `grant_type=password&client_id=cognito&client_secret=c0f105ad-f5ac-4ee3-8715-8e61e04f5be0&username=${event.userName}&password=${event.request.password}`, { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
            if (response.status !== 200) {
                throw new Error('Authentication against Keycloak failed');
            }
            // Set the response attributes
            event.response.finalUserStatus = 'CONFIRMED';
            event.response.messageAction = 'SUPPRESS';
            event.response.userAttributes = {
                email_verified: 'true',
            };
            // Retrieve additional user attributes from Keycloak and populate them in event.response.userAttributes
        }
        catch (err) {
            console.error(err);
            throw err;
        }
    }
    else {
        throw new Error(`Bad TriggerSource ${event.triggerSource}`);
    }
    return event;
};
exports.migrateUserHandler = migrateUserHandler;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWlncmF0ZS11c2VyLWhhbmRsZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJtaWdyYXRlLXVzZXItaGFuZGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxpR0FBaUc7QUFFakcsaURBQWlEO0FBQ2pELGlDQUEwQixDQUFDLDRDQUE0QztBQUd2RSxNQUFNLHVCQUF1QixHQUFHLElBQUksOEJBQThCLEVBQUUsQ0FBQztBQUU5RCxNQUFNLHVCQUF1QixHQUFHLENBQUMsS0FBZ0IsRUFBRSxFQUFVLEVBQW1CLEVBQUU7SUFDdkYsT0FBTyxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtRQUNwQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXO1FBQ25DLE9BQU8sRUFBRSx3Q0FBd0M7UUFDakQsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQztLQUN2QyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFOVyxRQUFBLHVCQUF1QiwyQkFNbEM7QUFFSyxNQUFNLGtCQUFrQixHQUFHLEtBQUssRUFBRSxLQUFVLEVBQWdCLEVBQUU7SUFDbkUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFFdEQsSUFBSSxLQUFLLENBQUMsYUFBYSxLQUFLLDhCQUE4QixFQUFFO1FBQzFELElBQUk7WUFDRixxREFBcUQ7WUFDckQsTUFBTSxRQUFRLEdBQUcsTUFBTSxlQUFLLENBQUMsSUFBSSxDQUMvQixxR0FBcUcsRUFDckcscUdBQXFHLEtBQUssQ0FBQyxRQUFRLGFBQWEsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFDeEosRUFBRSxPQUFPLEVBQUUsRUFBRSxjQUFjLEVBQUUsbUNBQW1DLEVBQUUsRUFBRSxDQUNyRSxDQUFDO1lBRUYsSUFBSSxRQUFRLENBQUMsTUFBTSxLQUFLLEdBQUcsRUFBRTtnQkFDM0IsTUFBTSxJQUFJLEtBQUssQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDO2FBQzNEO1lBRUQsOEJBQThCO1lBQzlCLEtBQUssQ0FBQyxRQUFRLENBQUMsZUFBZSxHQUFHLFdBQVcsQ0FBQztZQUM3QyxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsR0FBRyxVQUFVLENBQUM7WUFDMUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjLEdBQUc7Z0JBQzlCLGNBQWMsRUFBRSxNQUFNO2FBQ3ZCLENBQUM7WUFFRix1R0FBdUc7U0FFeEc7UUFBQyxPQUFPLEdBQUcsRUFBRTtZQUNaLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDbkIsTUFBTSxHQUFHLENBQUM7U0FDWDtLQUNGO1NBQU07UUFDTCxNQUFNLElBQUksS0FBSyxDQUFDLHFCQUFxQixLQUFLLENBQUMsYUFBYSxFQUFFLENBQUMsQ0FBQztLQUM3RDtJQUVELE9BQU8sS0FBSyxDQUFDO0FBQ2YsQ0FBQyxDQUFDO0FBbENXLFFBQUEsa0JBQWtCLHNCQWtDN0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBDb2duaXRvSWRlbnRpdHlTZXJ2aWNlUHJvdmlkZXIgZnJvbSAnYXdzLXNkay9jbGllbnRzL2NvZ25pdG9pZGVudGl0eXNlcnZpY2Vwcm92aWRlcic7XG5pbXBvcnQgeyBDb2duaXRvVXNlclBvb2xUcmlnZ2VyRXZlbnQgfSBmcm9tICdhd3MtbGFtYmRhJztcbmltcG9ydCAqIGFzIGxhbWJkYSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtbGFtYmRhJztcbmltcG9ydCBheGlvcyBmcm9tICdheGlvcyc7IC8vIFlvdSBtYXkgbmVlZCB0byBpbnN0YWxsIHRoZSBheGlvcyBwYWNrYWdlXG5pbXBvcnQgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcblxuY29uc3QgY29nbml0b0lkZW50aXR5UHJvdmlkZXIgPSBuZXcgQ29nbml0b0lkZW50aXR5U2VydmljZVByb3ZpZGVyKCk7XG5cbmV4cG9ydCBjb25zdCBjcmVhdGVNaWdyYXRlVXNlckxhbWJkYSA9IChzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nKTogbGFtYmRhLkZ1bmN0aW9uID0+IHtcbiAgcmV0dXJuIG5ldyBsYW1iZGEuRnVuY3Rpb24oc2NvcGUsIGlkLCB7XG4gICAgcnVudGltZTogbGFtYmRhLlJ1bnRpbWUuTk9ERUpTXzE4X1gsXG4gICAgaGFuZGxlcjogJ21pZ3JhdGUtdXNlci1sYW1iZGEubWlncmF0ZVVzZXJIYW5kbGVyJyxcbiAgICBjb2RlOiBsYW1iZGEuQ29kZS5mcm9tQXNzZXQoX19kaXJuYW1lKSwgXG4gIH0pO1xufTtcblxuZXhwb3J0IGNvbnN0IG1pZ3JhdGVVc2VySGFuZGxlciA9IGFzeW5jIChldmVudDogYW55KTogUHJvbWlzZTxhbnk+ID0+IHtcbiAgY29uc29sZS5sb2coJ1JlY2VpdmVkIGV2ZW50OicsIEpTT04uc3RyaW5naWZ5KGV2ZW50KSk7XG5cbiAgaWYgKGV2ZW50LnRyaWdnZXJTb3VyY2UgPT09ICdVc2VyTWlncmF0aW9uX0F1dGhlbnRpY2F0aW9uJykge1xuICAgIHRyeSB7XG4gICAgICAvLyBBdXRoZW50aWNhdGUgYWdhaW5zdCBLZXljbG9hayB1c2luZyBPcGVuSUQgQ29ubmVjdFxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBheGlvcy5wb3N0KFxuICAgICAgICAnaHR0cHM6Ly9rZXljbG9hay5ub3ZhY2xvTWlncmF0ZVVzZXJMYW1iZGF1ZC5hcHAvYXV0aC9yZWFsbXMvcmVrYXAtZGV2L3Byb3RvY29sL29wZW5pZC1jb25uZWN0L3Rva2VuJyxcbiAgICAgICAgYGdyYW50X3R5cGU9cGFzc3dvcmQmY2xpZW50X2lkPWNvZ25pdG8mY2xpZW50X3NlY3JldD1jMGYxMDVhZC1mNWFjLTRlZTMtODcxNS04ZTYxZTA0ZjViZTAmdXNlcm5hbWU9JHtldmVudC51c2VyTmFtZX0mcGFzc3dvcmQ9JHtldmVudC5yZXF1ZXN0LnBhc3N3b3JkfWAsXG4gICAgICAgIHsgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZCcgfSB9XG4gICAgICApO1xuXG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzICE9PSAyMDApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdBdXRoZW50aWNhdGlvbiBhZ2FpbnN0IEtleWNsb2FrIGZhaWxlZCcpO1xuICAgICAgfVxuICAgICAgXG4gICAgICAvLyBTZXQgdGhlIHJlc3BvbnNlIGF0dHJpYnV0ZXNcbiAgICAgIGV2ZW50LnJlc3BvbnNlLmZpbmFsVXNlclN0YXR1cyA9ICdDT05GSVJNRUQnO1xuICAgICAgZXZlbnQucmVzcG9uc2UubWVzc2FnZUFjdGlvbiA9ICdTVVBQUkVTUyc7XG4gICAgICBldmVudC5yZXNwb25zZS51c2VyQXR0cmlidXRlcyA9IHtcbiAgICAgICAgZW1haWxfdmVyaWZpZWQ6ICd0cnVlJyxcbiAgICAgIH07XG5cbiAgICAgIC8vIFJldHJpZXZlIGFkZGl0aW9uYWwgdXNlciBhdHRyaWJ1dGVzIGZyb20gS2V5Y2xvYWsgYW5kIHBvcHVsYXRlIHRoZW0gaW4gZXZlbnQucmVzcG9uc2UudXNlckF0dHJpYnV0ZXNcblxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoYEJhZCBUcmlnZ2VyU291cmNlICR7ZXZlbnQudHJpZ2dlclNvdXJjZX1gKTtcbiAgfVxuXG4gIHJldHVybiBldmVudDtcbn07XG5cblxuIl19
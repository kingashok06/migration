"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CognitoStack = void 0;
const aws = require("aws-sdk");
const migrate_user_handler_1 = require("./migrate-user-handler");
const cdk = require("aws-cdk-lib");
const cognito = require("aws-cdk-lib/aws-cognito");
const ses = require("aws-cdk-lib/aws-ses");
const iam = require("aws-cdk-lib/aws-iam");
class CognitoStack extends cdk.Stack {
    constructor(scope, id, props) {
        super(scope, id, props);
        const sesClient = new aws.SES();
        // Check if the email identity already exists
        sesClient.getIdentityVerificationAttributes({
            Identities: ['yugank@brainerhub.com'],
        }, (err, data) => {
            if (err) {
                // An error occurred, handle it as needed
                console.error('Error checking email identity:', err);
                return;
            }
            if (data.VerificationAttributes && data.VerificationAttributes['yugank@brainerhub.com']) {
                // Email identity exists, no need to create it
                console.log('Email identity already exists:', data.VerificationAttributes['yugank@brainerhub.com']);
                return;
            }
            // Create an Amazon SES Identity for your email address
            const emailIdentity = new ses.CfnEmailIdentity(this, 'EmailIdentity', {
                emailIdentity: 'yugank@brainerhub.com',
            });
            // Add a policy statement to allow Cognito to send emails through SES
            new iam.PolicyStatement({
                actions: ['ses:SendEmail', 'ses:SendRawEmail'],
                effect: iam.Effect.ALLOW,
                principals: [new iam.ServicePrincipal('cognito-idp.amazonaws.com')],
                resources: [emailIdentity.ref], // The ARN of the SES identity
            });
        });
        // Create a Cognito User Pool
        const userPoolProps = {
            userPoolName: 'UserPool',
            selfSignUpEnabled: false,
            signInAliases: { email: true },
            autoVerify: { email: true },
            passwordPolicy: {
                minLength: 7,
                requireLowercase: true,
                // requireUppercase: true,
                // requireDigits: true,
                // requireSymbols: true,
            },
        };
        const userPool = new cognito.UserPool(this, 'UserPool', userPoolProps);
        // Add a custom domain to the User Pool
        const domain = userPool.addDomain('CustomDomain', {
            cognitoDomain: {
                domainPrefix: 'auth', // Replace with your preferred subdomain prefix
            },
        });
        // // Associate an ACM certificate with the custom domain
        // domain.addCertificate('AcmCertificate', {
        //   certificate: certificateFromAcm, // Replace with your ACM certificate
        // });
        // Output the custom domain URL
        new cdk.CfnOutput(this, 'CustomDomainUrl', {
            value: domain.domainName,
        });
        // Inside the CognitoStack class
        const migrateUserLambda = (0, migrate_user_handler_1.createMigrateUserLambda)(this, 'MigrateUserLambda');
        // Define the User Pool trigger
        userPool.addTrigger(cognito.UserPoolOperation.PRE_AUTHENTICATION, migrateUserLambda);
        // Create an App Client for the User Pool
        const appClient = userPool.addClient('AppClient', {
            authFlows: { adminUserPassword: true },
        });
        // Output the Cognito User Pool ID and App Client ID
        new cdk.CfnOutput(this, 'UserPoolId', {
            value: userPool.userPoolId,
        });
        new cdk.CfnOutput(this, 'AppClientId', {
            value: appClient.userPoolClientId,
        });
    }
}
exports.CognitoStack = CognitoStack;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29nbml0by1zdGFjay5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNvZ25pdG8tc3RhY2sudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsK0JBQStCO0FBQy9CLGlFQUFpRTtBQUNqRSxtQ0FBbUM7QUFDbkMsbURBQW1EO0FBQ25ELDJDQUEyQztBQUMzQywyQ0FBMkM7QUFHM0MsTUFBYSxZQUFhLFNBQVEsR0FBRyxDQUFDLEtBQUs7SUFDekMsWUFBWSxLQUFnQixFQUFFLEVBQVUsRUFBRSxLQUFzQjtRQUM5RCxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN4QixNQUFNLFNBQVMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUU5Qiw2Q0FBNkM7UUFDN0MsU0FBUyxDQUFDLGlDQUFpQyxDQUFDO1lBQzFDLFVBQVUsRUFBRSxDQUFDLHVCQUF1QixDQUFDO1NBQ3RDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDZixJQUFJLEdBQUcsRUFBRTtnQkFDUCx5Q0FBeUM7Z0JBQ3pDLE9BQU8sQ0FBQyxLQUFLLENBQUMsZ0NBQWdDLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ3JELE9BQU87YUFDUjtZQUVELElBQUksSUFBSSxDQUFDLHNCQUFzQixJQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyx1QkFBdUIsQ0FBQyxFQUFFO2dCQUN2Riw4Q0FBOEM7Z0JBQzlDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLEVBQUUsSUFBSSxDQUFDLHNCQUFzQixDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQztnQkFDcEcsT0FBTzthQUNSO1lBRUQsdURBQXVEO1lBQ3ZELE1BQU0sYUFBYSxHQUFHLElBQUksR0FBRyxDQUFDLGdCQUFnQixDQUFDLElBQUksRUFBRSxlQUFlLEVBQUU7Z0JBQ3BFLGFBQWEsRUFBRSx1QkFBdUI7YUFDdkMsQ0FBQyxDQUFDO1lBRUgscUVBQXFFO1lBQ3JFLElBQUksR0FBRyxDQUFDLGVBQWUsQ0FBQztnQkFDdEIsT0FBTyxFQUFFLENBQUMsZUFBZSxFQUFFLGtCQUFrQixDQUFDO2dCQUM5QyxNQUFNLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLO2dCQUN4QixVQUFVLEVBQUUsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO2dCQUNuRSxTQUFTLEVBQUUsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEVBQUUsOEJBQThCO2FBQy9ELENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsNkJBQTZCO1FBQzdCLE1BQU0sYUFBYSxHQUEwQjtZQUMzQyxZQUFZLEVBQUUsVUFBVTtZQUN4QixpQkFBaUIsRUFBRSxLQUFLO1lBQ3hCLGFBQWEsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDOUIsVUFBVSxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRTtZQUMzQixjQUFjLEVBQUU7Z0JBQ2QsU0FBUyxFQUFFLENBQUM7Z0JBQ1osZ0JBQWdCLEVBQUUsSUFBSTtnQkFDdEIsMEJBQTBCO2dCQUMxQix1QkFBdUI7Z0JBQ3ZCLHdCQUF3QjthQUN6QjtTQUNGLENBQUM7UUFFSixNQUFNLFFBQVEsR0FBRyxJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLFVBQVUsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUV2RSx1Q0FBdUM7UUFDdkMsTUFBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUU7WUFDaEQsYUFBYSxFQUFFO2dCQUNiLFlBQVksRUFBRSxNQUFNLEVBQUUsK0NBQStDO2FBQ3RFO1NBQ0YsQ0FBQyxDQUFDO1FBRUgseURBQXlEO1FBQ3pELDRDQUE0QztRQUM1QywwRUFBMEU7UUFDMUUsTUFBTTtRQUVOLCtCQUErQjtRQUMvQixJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLGlCQUFpQixFQUFFO1lBQ3pDLEtBQUssRUFBRSxNQUFNLENBQUMsVUFBVTtTQUN6QixDQUFDLENBQUM7UUFFSCxnQ0FBZ0M7UUFDaEMsTUFBTSxpQkFBaUIsR0FBRyxJQUFBLDhDQUF1QixFQUFDLElBQUksRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO1FBRTdFLCtCQUErQjtRQUMvQixRQUFRLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxrQkFBa0IsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO1FBRXJGLHlDQUF5QztRQUN6QyxNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRTtZQUNoRCxTQUFTLEVBQUUsRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUU7U0FDdkMsQ0FBQyxDQUFDO1FBRUgsb0RBQW9EO1FBQ3BELElBQUksR0FBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFO1lBQ3BDLEtBQUssRUFBRSxRQUFRLENBQUMsVUFBVTtTQUMzQixDQUFDLENBQUM7UUFFSCxJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUNyQyxLQUFLLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtTQUNsQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUF6RkQsb0NBeUZDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgYXdzIGZyb20gJ2F3cy1zZGsnO1xuaW1wb3J0IHsgY3JlYXRlTWlncmF0ZVVzZXJMYW1iZGEgfSBmcm9tICcuL21pZ3JhdGUtdXNlci1oYW5kbGVyJztcbmltcG9ydCAqIGFzIGNkayBmcm9tICdhd3MtY2RrLWxpYic7XG5pbXBvcnQgKiBhcyBjb2duaXRvIGZyb20gJ2F3cy1jZGstbGliL2F3cy1jb2duaXRvJztcbmltcG9ydCAqIGFzIHNlcyBmcm9tICdhd3MtY2RrLWxpYi9hd3Mtc2VzJztcbmltcG9ydCAqIGFzIGlhbSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCB7IENvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuXG5leHBvcnQgY2xhc3MgQ29nbml0b1N0YWNrIGV4dGVuZHMgY2RrLlN0YWNrIHtcbiAgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM/OiBjZGsuU3RhY2tQcm9wcykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwgcHJvcHMpO1xuICAgIGNvbnN0IHNlc0NsaWVudCA9IG5ldyBhd3MuU0VTKCk7XG5cbiAgICAgIC8vIENoZWNrIGlmIHRoZSBlbWFpbCBpZGVudGl0eSBhbHJlYWR5IGV4aXN0c1xuICAgICAgc2VzQ2xpZW50LmdldElkZW50aXR5VmVyaWZpY2F0aW9uQXR0cmlidXRlcyh7XG4gICAgICAgIElkZW50aXRpZXM6IFsneXVnYW5rQGJyYWluZXJodWIuY29tJ10sXG4gICAgICB9LCAoZXJyLCBkYXRhKSA9PiB7XG4gICAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgICAvLyBBbiBlcnJvciBvY2N1cnJlZCwgaGFuZGxlIGl0IGFzIG5lZWRlZFxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGNoZWNraW5nIGVtYWlsIGlkZW50aXR5OicsIGVycik7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gIFxuICAgICAgICBpZiAoZGF0YS5WZXJpZmljYXRpb25BdHRyaWJ1dGVzICYmIGRhdGEuVmVyaWZpY2F0aW9uQXR0cmlidXRlc1sneXVnYW5rQGJyYWluZXJodWIuY29tJ10pIHtcbiAgICAgICAgICAvLyBFbWFpbCBpZGVudGl0eSBleGlzdHMsIG5vIG5lZWQgdG8gY3JlYXRlIGl0XG4gICAgICAgICAgY29uc29sZS5sb2coJ0VtYWlsIGlkZW50aXR5IGFscmVhZHkgZXhpc3RzOicsIGRhdGEuVmVyaWZpY2F0aW9uQXR0cmlidXRlc1sneXVnYW5rQGJyYWluZXJodWIuY29tJ10pO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICBcbiAgICAgICAgLy8gQ3JlYXRlIGFuIEFtYXpvbiBTRVMgSWRlbnRpdHkgZm9yIHlvdXIgZW1haWwgYWRkcmVzc1xuICAgICAgICBjb25zdCBlbWFpbElkZW50aXR5ID0gbmV3IHNlcy5DZm5FbWFpbElkZW50aXR5KHRoaXMsICdFbWFpbElkZW50aXR5Jywge1xuICAgICAgICAgIGVtYWlsSWRlbnRpdHk6ICd5dWdhbmtAYnJhaW5lcmh1Yi5jb20nLCBcbiAgICAgICAgfSk7XG4gIFxuICAgICAgICAvLyBBZGQgYSBwb2xpY3kgc3RhdGVtZW50IHRvIGFsbG93IENvZ25pdG8gdG8gc2VuZCBlbWFpbHMgdGhyb3VnaCBTRVNcbiAgICAgICAgbmV3IGlhbS5Qb2xpY3lTdGF0ZW1lbnQoe1xuICAgICAgICAgIGFjdGlvbnM6IFsnc2VzOlNlbmRFbWFpbCcsICdzZXM6U2VuZFJhd0VtYWlsJ10sXG4gICAgICAgICAgZWZmZWN0OiBpYW0uRWZmZWN0LkFMTE9XLFxuICAgICAgICAgIHByaW5jaXBhbHM6IFtuZXcgaWFtLlNlcnZpY2VQcmluY2lwYWwoJ2NvZ25pdG8taWRwLmFtYXpvbmF3cy5jb20nKV0sXG4gICAgICAgICAgcmVzb3VyY2VzOiBbZW1haWxJZGVudGl0eS5yZWZdLCAvLyBUaGUgQVJOIG9mIHRoZSBTRVMgaWRlbnRpdHlcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgXG4gICAgICAvLyBDcmVhdGUgYSBDb2duaXRvIFVzZXIgUG9vbFxuICAgICAgY29uc3QgdXNlclBvb2xQcm9wczogY29nbml0by5Vc2VyUG9vbFByb3BzID0ge1xuICAgICAgICB1c2VyUG9vbE5hbWU6ICdVc2VyUG9vbCcsXG4gICAgICAgIHNlbGZTaWduVXBFbmFibGVkOiBmYWxzZSwgLy8gQWxsb3cgdXNlcnMgdG8gc2lnbiB1cCB0aGVtc2VsdmVzXG4gICAgICAgIHNpZ25JbkFsaWFzZXM6IHsgZW1haWw6IHRydWUgfSwgLy8gRW5hYmxlIHNpZ24taW4gd2l0aCBlbWFpbFxuICAgICAgICBhdXRvVmVyaWZ5OiB7IGVtYWlsOiB0cnVlIH0sIC8vIEF1dG9tYXRpY2FsbHkgdmVyaWZ5IGVtYWlsIGFkZHJlc3Nlc1xuICAgICAgICBwYXNzd29yZFBvbGljeToge1xuICAgICAgICAgIG1pbkxlbmd0aDogNywgLy8gU2V0IHBhc3N3b3JkIHBvbGljeSBcbiAgICAgICAgICByZXF1aXJlTG93ZXJjYXNlOiB0cnVlLFxuICAgICAgICAgIC8vIHJlcXVpcmVVcHBlcmNhc2U6IHRydWUsXG4gICAgICAgICAgLy8gcmVxdWlyZURpZ2l0czogdHJ1ZSxcbiAgICAgICAgICAvLyByZXF1aXJlU3ltYm9sczogdHJ1ZSxcbiAgICAgICAgfSxcbiAgICAgIH07XG5cbiAgICBjb25zdCB1c2VyUG9vbCA9IG5ldyBjb2duaXRvLlVzZXJQb29sKHRoaXMsICdVc2VyUG9vbCcsIHVzZXJQb29sUHJvcHMpO1xuXG4gICAgLy8gQWRkIGEgY3VzdG9tIGRvbWFpbiB0byB0aGUgVXNlciBQb29sXG4gICAgY29uc3QgZG9tYWluID0gdXNlclBvb2wuYWRkRG9tYWluKCdDdXN0b21Eb21haW4nLCB7XG4gICAgICBjb2duaXRvRG9tYWluOiB7XG4gICAgICAgIGRvbWFpblByZWZpeDogJ2F1dGgnLCAvLyBSZXBsYWNlIHdpdGggeW91ciBwcmVmZXJyZWQgc3ViZG9tYWluIHByZWZpeFxuICAgICAgfSxcbiAgICB9KTtcblxuICAgIC8vIC8vIEFzc29jaWF0ZSBhbiBBQ00gY2VydGlmaWNhdGUgd2l0aCB0aGUgY3VzdG9tIGRvbWFpblxuICAgIC8vIGRvbWFpbi5hZGRDZXJ0aWZpY2F0ZSgnQWNtQ2VydGlmaWNhdGUnLCB7XG4gICAgLy8gICBjZXJ0aWZpY2F0ZTogY2VydGlmaWNhdGVGcm9tQWNtLCAvLyBSZXBsYWNlIHdpdGggeW91ciBBQ00gY2VydGlmaWNhdGVcbiAgICAvLyB9KTtcblxuICAgIC8vIE91dHB1dCB0aGUgY3VzdG9tIGRvbWFpbiBVUkxcbiAgICBuZXcgY2RrLkNmbk91dHB1dCh0aGlzLCAnQ3VzdG9tRG9tYWluVXJsJywge1xuICAgICAgdmFsdWU6IGRvbWFpbi5kb21haW5OYW1lLFxuICAgIH0pO1xuXG4gICAgLy8gSW5zaWRlIHRoZSBDb2duaXRvU3RhY2sgY2xhc3NcbiAgICBjb25zdCBtaWdyYXRlVXNlckxhbWJkYSA9IGNyZWF0ZU1pZ3JhdGVVc2VyTGFtYmRhKHRoaXMsICdNaWdyYXRlVXNlckxhbWJkYScpO1xuXG4gICAgLy8gRGVmaW5lIHRoZSBVc2VyIFBvb2wgdHJpZ2dlclxuICAgIHVzZXJQb29sLmFkZFRyaWdnZXIoY29nbml0by5Vc2VyUG9vbE9wZXJhdGlvbi5QUkVfQVVUSEVOVElDQVRJT04sIG1pZ3JhdGVVc2VyTGFtYmRhKTtcblxuICAgIC8vIENyZWF0ZSBhbiBBcHAgQ2xpZW50IGZvciB0aGUgVXNlciBQb29sXG4gICAgY29uc3QgYXBwQ2xpZW50ID0gdXNlclBvb2wuYWRkQ2xpZW50KCdBcHBDbGllbnQnLCB7XG4gICAgICBhdXRoRmxvd3M6IHsgYWRtaW5Vc2VyUGFzc3dvcmQ6IHRydWUgfSxcbiAgICB9KTtcblxuICAgIC8vIE91dHB1dCB0aGUgQ29nbml0byBVc2VyIFBvb2wgSUQgYW5kIEFwcCBDbGllbnQgSURcbiAgICBuZXcgY2RrLkNmbk91dHB1dCh0aGlzLCAnVXNlclBvb2xJZCcsIHtcbiAgICAgIHZhbHVlOiB1c2VyUG9vbC51c2VyUG9vbElkLFxuICAgIH0pO1xuXG4gICAgbmV3IGNkay5DZm5PdXRwdXQodGhpcywgJ0FwcENsaWVudElkJywge1xuICAgICAgdmFsdWU6IGFwcENsaWVudC51c2VyUG9vbENsaWVudElkLFxuICAgIH0pO1xuICB9XG59XG4iXX0=
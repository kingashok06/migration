"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CognitoStack = void 0;
const aws = require("aws-sdk");
const migrate_user_handler_1 = require("./migrate-user-handler");
const cdk = require("aws-cdk-lib");
const cognito = require("aws-cdk-lib/aws-cognito");
const ses = require("aws-cdk-lib/aws-ses");
const iam = require("aws-cdk-lib/aws-iam");
class CognitoStack extends cdk.Stack {
    constructor(scope, id, props) {
        super(scope, id, props);
        const sesClient = new aws.SES();
        // Check if the email identity already exists
        sesClient.getIdentityVerificationAttributes({
            Identities: ['yugank@brainerhub.com'],
        }, (err, data) => {
            if (err) {
                // An error occurred, handle it as needed
                console.error('Error checking email identity:', err);
                return;
            }
            if (data.VerificationAttributes && data.VerificationAttributes['yugank@brainerhub.com']) {
                // Email identity exists, no need to create it
                console.log('Email identity already exists:', data.VerificationAttributes['yugank@brainerhub.com']);
                return;
            }
            // Create an Amazon SES Identity for your email address
            const emailIdentity = new ses.CfnEmailIdentity(this, 'EmailIdentity', {
                emailIdentity: 'yugank@brainerhub.com',
            });
            // Add a policy statement to allow Cognito to send emails through SES
            new iam.PolicyStatement({
                actions: ['ses:SendEmail', 'ses:SendRawEmail'],
                effect: iam.Effect.ALLOW,
                principals: [new iam.ServicePrincipal('cognito-idp.amazonaws.com')],
                resources: [emailIdentity.ref], // The ARN of the SES identity
            });
        });
        // Create a Cognito User Pool
        const userPoolProps = {
            userPoolName: 'UserPool',
            selfSignUpEnabled: false,
            signInAliases: { email: true },
            autoVerify: { email: true },
            passwordPolicy: {
                minLength: 7,
                requireLowercase: true,
                // requireUppercase: true,
                // requireDigits: true,
                // requireSymbols: true,
            },
        };
        const userPool = new cognito.UserPool(this, 'UserPool', userPoolProps);
        // Inside the CognitoStack class
        const migrateUserLambda = (0, migrate_user_handler_1.createMigrateUserLambda)(this, 'MigrateUserLambda');
        // Define the User Pool trigger
        userPool.addTrigger(cognito.UserPoolOperation.PRE_AUTHENTICATION, migrateUserLambda);
        // Create an App Client for the User Pool
        const appClient = userPool.addClient('AppClient', {
            authFlows: { adminUserPassword: true },
        });
        // Output the Cognito User Pool ID and App Client ID
        new cdk.CfnOutput(this, 'UserPoolId', {
            value: userPool.userPoolId,
        });
        new cdk.CfnOutput(this, 'AppClientId', {
            value: appClient.userPoolClientId,
        });
    }
}
exports.CognitoStack = CognitoStack;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29nbml0by1zdGFjay5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNvZ25pdG8tc3RhY2sudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsK0JBQStCO0FBQy9CLGlFQUFpRTtBQUNqRSxtQ0FBbUM7QUFDbkMsbURBQW1EO0FBQ25ELDJDQUEyQztBQUMzQywyQ0FBMkM7QUFHM0MsTUFBYSxZQUFhLFNBQVEsR0FBRyxDQUFDLEtBQUs7SUFDekMsWUFBWSxLQUFnQixFQUFFLEVBQVUsRUFBRSxLQUFzQjtRQUM5RCxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN4QixNQUFNLFNBQVMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUVoQyw2Q0FBNkM7UUFDN0MsU0FBUyxDQUFDLGlDQUFpQyxDQUFDO1lBQzFDLFVBQVUsRUFBRSxDQUFDLHVCQUF1QixDQUFDO1NBQ3RDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDZixJQUFJLEdBQUcsRUFBRTtnQkFDUCx5Q0FBeUM7Z0JBQ3pDLE9BQU8sQ0FBQyxLQUFLLENBQUMsZ0NBQWdDLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBQ3JELE9BQU87YUFDUjtZQUVELElBQUksSUFBSSxDQUFDLHNCQUFzQixJQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyx1QkFBdUIsQ0FBQyxFQUFFO2dCQUN2Riw4Q0FBOEM7Z0JBQzlDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLEVBQUUsSUFBSSxDQUFDLHNCQUFzQixDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQztnQkFDcEcsT0FBTzthQUNSO1lBRUQsdURBQXVEO1lBQ3ZELE1BQU0sYUFBYSxHQUFHLElBQUksR0FBRyxDQUFDLGdCQUFnQixDQUFDLElBQUksRUFBRSxlQUFlLEVBQUU7Z0JBQ3BFLGFBQWEsRUFBRSx1QkFBdUI7YUFDdkMsQ0FBQyxDQUFDO1lBRUgscUVBQXFFO1lBQ3JFLElBQUksR0FBRyxDQUFDLGVBQWUsQ0FBQztnQkFDdEIsT0FBTyxFQUFFLENBQUMsZUFBZSxFQUFFLGtCQUFrQixDQUFDO2dCQUM5QyxNQUFNLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLO2dCQUN4QixVQUFVLEVBQUUsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO2dCQUNuRSxTQUFTLEVBQUUsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEVBQUUsOEJBQThCO2FBQy9ELENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsNkJBQTZCO1FBQzdCLE1BQU0sYUFBYSxHQUEwQjtZQUMzQyxZQUFZLEVBQUUsVUFBVTtZQUN4QixpQkFBaUIsRUFBRSxLQUFLO1lBQ3hCLGFBQWEsRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUU7WUFDOUIsVUFBVSxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRTtZQUMzQixjQUFjLEVBQUU7Z0JBQ2QsU0FBUyxFQUFFLENBQUM7Z0JBQ1osZ0JBQWdCLEVBQUUsSUFBSTtnQkFDdEIsMEJBQTBCO2dCQUMxQix1QkFBdUI7Z0JBQ3ZCLHdCQUF3QjthQUN6QjtTQUNGLENBQUM7UUFHRixNQUFNLFFBQVEsR0FBRyxJQUFJLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLFVBQVUsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUN2RSxnQ0FBZ0M7UUFDaEMsTUFBTSxpQkFBaUIsR0FBRyxJQUFBLDhDQUF1QixFQUFDLElBQUksRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO1FBRzdFLCtCQUErQjtRQUUvQixRQUFRLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxrQkFBa0IsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO1FBR3JGLHlDQUF5QztRQUN6QyxNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRTtZQUNoRCxTQUFTLEVBQUUsRUFBRSxpQkFBaUIsRUFBRSxJQUFJLEVBQUU7U0FDdkMsQ0FBQyxDQUFDO1FBRUgsb0RBQW9EO1FBQ3BELElBQUksR0FBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsWUFBWSxFQUFFO1lBQ3BDLEtBQUssRUFBRSxRQUFRLENBQUMsVUFBVTtTQUMzQixDQUFDLENBQUM7UUFFSCxJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLGFBQWEsRUFBRTtZQUNyQyxLQUFLLEVBQUUsU0FBUyxDQUFDLGdCQUFnQjtTQUNsQyxDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUEzRUQsb0NBMkVDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgYXdzIGZyb20gJ2F3cy1zZGsnO1xuaW1wb3J0IHsgY3JlYXRlTWlncmF0ZVVzZXJMYW1iZGEgfSBmcm9tICcuL21pZ3JhdGUtdXNlci1oYW5kbGVyJztcbmltcG9ydCAqIGFzIGNkayBmcm9tICdhd3MtY2RrLWxpYic7XG5pbXBvcnQgKiBhcyBjb2duaXRvIGZyb20gJ2F3cy1jZGstbGliL2F3cy1jb2duaXRvJztcbmltcG9ydCAqIGFzIHNlcyBmcm9tICdhd3MtY2RrLWxpYi9hd3Mtc2VzJztcbmltcG9ydCAqIGFzIGlhbSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtaWFtJztcbmltcG9ydCB7IENvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuXG5leHBvcnQgY2xhc3MgQ29nbml0b1N0YWNrIGV4dGVuZHMgY2RrLlN0YWNrIHtcbiAgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM/OiBjZGsuU3RhY2tQcm9wcykge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwgcHJvcHMpO1xuICAgIGNvbnN0IHNlc0NsaWVudCA9IG5ldyBhd3MuU0VTKCk7XG5cbiAgICAvLyBDaGVjayBpZiB0aGUgZW1haWwgaWRlbnRpdHkgYWxyZWFkeSBleGlzdHNcbiAgICBzZXNDbGllbnQuZ2V0SWRlbnRpdHlWZXJpZmljYXRpb25BdHRyaWJ1dGVzKHtcbiAgICAgIElkZW50aXRpZXM6IFsneXVnYW5rQGJyYWluZXJodWIuY29tJ10sXG4gICAgfSwgKGVyciwgZGF0YSkgPT4ge1xuICAgICAgaWYgKGVycikge1xuICAgICAgICAvLyBBbiBlcnJvciBvY2N1cnJlZCwgaGFuZGxlIGl0IGFzIG5lZWRlZFxuICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBjaGVja2luZyBlbWFpbCBpZGVudGl0eTonLCBlcnIpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIGlmIChkYXRhLlZlcmlmaWNhdGlvbkF0dHJpYnV0ZXMgJiYgZGF0YS5WZXJpZmljYXRpb25BdHRyaWJ1dGVzWyd5dWdhbmtAYnJhaW5lcmh1Yi5jb20nXSkge1xuICAgICAgICAvLyBFbWFpbCBpZGVudGl0eSBleGlzdHMsIG5vIG5lZWQgdG8gY3JlYXRlIGl0XG4gICAgICAgIGNvbnNvbGUubG9nKCdFbWFpbCBpZGVudGl0eSBhbHJlYWR5IGV4aXN0czonLCBkYXRhLlZlcmlmaWNhdGlvbkF0dHJpYnV0ZXNbJ3l1Z2Fua0BicmFpbmVyaHViLmNvbSddKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBDcmVhdGUgYW4gQW1hem9uIFNFUyBJZGVudGl0eSBmb3IgeW91ciBlbWFpbCBhZGRyZXNzXG4gICAgICBjb25zdCBlbWFpbElkZW50aXR5ID0gbmV3IHNlcy5DZm5FbWFpbElkZW50aXR5KHRoaXMsICdFbWFpbElkZW50aXR5Jywge1xuICAgICAgICBlbWFpbElkZW50aXR5OiAneXVnYW5rQGJyYWluZXJodWIuY29tJywgXG4gICAgICB9KTtcblxuICAgICAgLy8gQWRkIGEgcG9saWN5IHN0YXRlbWVudCB0byBhbGxvdyBDb2duaXRvIHRvIHNlbmQgZW1haWxzIHRocm91Z2ggU0VTXG4gICAgICBuZXcgaWFtLlBvbGljeVN0YXRlbWVudCh7XG4gICAgICAgIGFjdGlvbnM6IFsnc2VzOlNlbmRFbWFpbCcsICdzZXM6U2VuZFJhd0VtYWlsJ10sXG4gICAgICAgIGVmZmVjdDogaWFtLkVmZmVjdC5BTExPVyxcbiAgICAgICAgcHJpbmNpcGFsczogW25ldyBpYW0uU2VydmljZVByaW5jaXBhbCgnY29nbml0by1pZHAuYW1hem9uYXdzLmNvbScpXSxcbiAgICAgICAgcmVzb3VyY2VzOiBbZW1haWxJZGVudGl0eS5yZWZdLCAvLyBUaGUgQVJOIG9mIHRoZSBTRVMgaWRlbnRpdHlcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgLy8gQ3JlYXRlIGEgQ29nbml0byBVc2VyIFBvb2xcbiAgICBjb25zdCB1c2VyUG9vbFByb3BzOiBjb2duaXRvLlVzZXJQb29sUHJvcHMgPSB7XG4gICAgICB1c2VyUG9vbE5hbWU6ICdVc2VyUG9vbCcsXG4gICAgICBzZWxmU2lnblVwRW5hYmxlZDogZmFsc2UsIC8vIEFsbG93IHVzZXJzIHRvIHNpZ24gdXAgdGhlbXNlbHZlc1xuICAgICAgc2lnbkluQWxpYXNlczogeyBlbWFpbDogdHJ1ZSB9LCAvLyBFbmFibGUgc2lnbi1pbiB3aXRoIGVtYWlsXG4gICAgICBhdXRvVmVyaWZ5OiB7IGVtYWlsOiB0cnVlIH0sIC8vIEF1dG9tYXRpY2FsbHkgdmVyaWZ5IGVtYWlsIGFkZHJlc3Nlc1xuICAgICAgcGFzc3dvcmRQb2xpY3k6IHtcbiAgICAgICAgbWluTGVuZ3RoOiA3LCAvLyBTZXQgcGFzc3dvcmQgcG9saWN5IFxuICAgICAgICByZXF1aXJlTG93ZXJjYXNlOiB0cnVlLFxuICAgICAgICAvLyByZXF1aXJlVXBwZXJjYXNlOiB0cnVlLFxuICAgICAgICAvLyByZXF1aXJlRGlnaXRzOiB0cnVlLFxuICAgICAgICAvLyByZXF1aXJlU3ltYm9sczogdHJ1ZSxcbiAgICAgIH0sXG4gICAgfTtcbiAgICBcbiAgICBcbiAgICBjb25zdCB1c2VyUG9vbCA9IG5ldyBjb2duaXRvLlVzZXJQb29sKHRoaXMsICdVc2VyUG9vbCcsIHVzZXJQb29sUHJvcHMpO1xuICAgIC8vIEluc2lkZSB0aGUgQ29nbml0b1N0YWNrIGNsYXNzXG4gICAgY29uc3QgbWlncmF0ZVVzZXJMYW1iZGEgPSBjcmVhdGVNaWdyYXRlVXNlckxhbWJkYSh0aGlzLCAnTWlncmF0ZVVzZXJMYW1iZGEnKTtcblxuXG4gICAgLy8gRGVmaW5lIHRoZSBVc2VyIFBvb2wgdHJpZ2dlclxuICAgIFxuICAgIHVzZXJQb29sLmFkZFRyaWdnZXIoY29nbml0by5Vc2VyUG9vbE9wZXJhdGlvbi5QUkVfQVVUSEVOVElDQVRJT04sIG1pZ3JhdGVVc2VyTGFtYmRhKTtcblxuXG4gICAgLy8gQ3JlYXRlIGFuIEFwcCBDbGllbnQgZm9yIHRoZSBVc2VyIFBvb2xcbiAgICBjb25zdCBhcHBDbGllbnQgPSB1c2VyUG9vbC5hZGRDbGllbnQoJ0FwcENsaWVudCcsIHtcbiAgICAgIGF1dGhGbG93czogeyBhZG1pblVzZXJQYXNzd29yZDogdHJ1ZSB9LFxuICAgIH0pO1xuXG4gICAgLy8gT3V0cHV0IHRoZSBDb2duaXRvIFVzZXIgUG9vbCBJRCBhbmQgQXBwIENsaWVudCBJRFxuICAgIG5ldyBjZGsuQ2ZuT3V0cHV0KHRoaXMsICdVc2VyUG9vbElkJywge1xuICAgICAgdmFsdWU6IHVzZXJQb29sLnVzZXJQb29sSWQsXG4gICAgfSk7XG5cbiAgICBuZXcgY2RrLkNmbk91dHB1dCh0aGlzLCAnQXBwQ2xpZW50SWQnLCB7XG4gICAgICB2YWx1ZTogYXBwQ2xpZW50LnVzZXJQb29sQ2xpZW50SWQsXG4gICAgfSk7XG4gIH1cbn1cblxuIl19
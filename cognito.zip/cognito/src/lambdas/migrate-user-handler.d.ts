import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
import * as cdk from 'aws-cdk-lib';
export declare const createMigrateUserLambda: (scope: Construct, id: string, bundlingOptions: cdk.aws_lambda_nodejs.BundlingOptions) => lambda.Function;
export declare const migrateUserHandler: (event: any) => Promise<any>;
